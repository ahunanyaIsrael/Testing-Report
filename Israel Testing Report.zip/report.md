# Name & Surname: Israel Ahunanya
# Date: 24 April 2025
# Project: Shadow error reporting


# Title: 
node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft]

# Description: 

At line:1 char:25
+ node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] ...
+                         ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title: 
node shadow.mjs to-pkh <bech32>

# Description:
At line:1 char:25
+  node shadow.mjs to-pkh <bech32>
+                         ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title: 
node shadow.mjs to-binary <bech32>

# Description:
At line:1 char:27
+ node shadow.mjs to-binary <bech32>
+                           ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title:
node shadow.mjs to-hex <bech32>


# Description: 
At line:1 char:25
+  node shadow.mjs to-hex <bech32>
+                         ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title: 
node shadow.mjs to-address <bech32>

# Description: 
At line:1 char:28
+ node shadow.mjs to-address <bech32>
+                            ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title: 
node shadow.mjs gen-keys [seed] [--mainnet]

# Description:
❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:
node shadow.mjs sign <hex-msg> <payment.skey>

# Description:
At line:1 char:22
+ node shadow.mjs sign <hex-msg> <payment.skey>
+                      ~
The '<' operator is reserved for future use.
At line:1 char:32
+ node shadow.mjs sign <hex-msg> <payment.skey>
+                                ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title: 
node shadow.mjs verify <hex-msg> <signature> <payment.vkey>

# Description:
At line:1 char:24
+ node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
+                        ~
The '<' operator is reserved for future use.
At line:1 char:34
+ node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
+                                  ~
The '<' operator is reserved for future use.
At line:1 char:46
+ node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
+                                              ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title:

node shadow.mjs hex-encode "Hello world"

# Description:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:
node shadow.mjs hex-decode 48656c6c6f20776f726c64

# Description:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:
node shadow.mjs str-to-bin "text"

# Description:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:
node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"

# Decription:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address


# Title:
node shadow.mjs hex-to-bin 74657874

# Description:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:
node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100" 

# Description:

❓ Unknown command

Shadow CLI Toolkit

    Usage: at the root folder terminal type node followed by the file shadow.mjs the the command e.g. to-pkh
    followed by the parameter <bech32> e.g. addr_test1qpnhjk2v44axnvhlccuqhlmky09fgn0tvrjlrm6tnzure9qkm0guvx66e0lsh4s22y3ywp2zpkkvhnv2a7jfu7jrr4vqw3zfl4
    pubkeyhash example: 6779594cad7a69b2ffc6380bff7623ca944deb60e5f1ef4b98b83c94

    List of commands and arguments:

    node shadow.mjs gen-wallet [--mainnet]
    node shadow.mjs compile <contract.hl> [--mainnet] [--staking] [--nft] [--show-cli]
    node shadow.mjs to-pkh <bech32>
    node shadow.mjs to-binary <bech32>
    node shadow.mjs to-hex <bech32>
    node shadow.mjs to-address <bech32>
    node shadow.mjs gen-keys [seed] [--mainnet]
    node shadow.mjs sign <hex-msg> <payment.skey>
    node shadow.mjs verify <hex-msg> <signature> <payment.vkey>
    node shadow.mjs hex-encode "Hello world"
    node shadow.mjs hex-decode 48656c6c6f20776f726c64
    node shadow.mjs str-to-bin "text"
    node shadow.mjs bin-to-str "01110100 01100101 01111000 01110100"
    node shadow.mjs hex-to-bin 74657874
    node shadow.mjs bin-to-hex "01110100 01100101 01111000 01110100"
    node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
    node helios-bech32-cli.js interactive


Commands:
  gen-wallet        Generate new payment/stake keys, addresses, mnemonic
  compile           Compile a Helios contract to .plutus, hash, and address

# Title:

node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]

# Description:
At line:1 char:37
+ node helios-bech32-cli.js to-bech32 <pubKeyHash-hex> [--mainnet]
+                                     ~
The '<' operator is reserved for future use.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : RedirectionNotSupported

# Title:
 node helios-bech32-cli.js interactive

# Description: 
node:internal/modules/cjs/loader:1228
  throw err;
  ^

Error: Cannot find module 'C:\coxygen\coxygen\shadow\helios-bech32-cli.js'
    at Function._resolveFilename (node:internal/modules/cjs/loader:1225:15)
    at Function._load (node:internal/modules/cjs/loader:1055:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:220:24)
    at Function.executeUserEntryPoint [as runMain] (node:internal/modules/run_main:170:5)
    at node:internal/main/run_main_module:36:49 {
  code: 'MODULE_NOT_FOUND',
  requireStack: []
}

